
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { HistoricalScenario, Source } from "../types";
import { decodeBase64, decodeAudioData } from "../utils/audioUtils";

const FLASH_MODEL = 'gemini-3-flash-preview'; 
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';
const IMAGE_MODEL = 'gemini-2.5-flash-image';

function extractJSON(text: string): any {
  let jsonString = text.trim().replace(/```json/gi, '').replace(/```/g, '');
  const firstOpen = jsonString.indexOf('{');
  const lastClose = jsonString.lastIndexOf('}');
  return JSON.parse(jsonString.substring(firstOpen, lastClose + 1));
}

export async function researchLocationAndDate(location: string, date: string): Promise<HistoricalScenario> {
  // Always initialize a new instance before making an API call to ensure use of the most up-to-date API key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Eres un historiador experto en México. 
    INVESTIGA EL SUCESO: "${location}" ${date ? `en la fecha ${date}` : "(FECHA DESCONOCIDA: Identifica el año y día más relevante para este suceso)"}.
    
    INSTRUCCIONES:
    1. Usa Google Search para ser preciso.
    2. Si el usuario no dio fecha, búscala.
    3. Crea un diálogo breve (4-5 líneas) en el idioma/variante original (Náhuatl, Maya, Español antiguo) con traducción.
    
    Voces: puck, charon, fenrir, zephyr (m); kore, aoede, leda, schedar (f).

    JSON:
    {
      "context": "Contexto histórico + Fecha identificada.",
      "accentProfile": "Acento de la época.",
      "characters": [
        {"name": "Nombre", "gender": "male|female", "voice": "voz", "visualDescription": "Aspecto", "bio": "Bio corta"}
      ],
      "script": [
        {"speaker": "Nombre", "text": "Idioma original", "translation": "Español", "annotations": [{"phrase": "término", "explanation": "Def"}]}
      ]
    }
  `;

  const response = await ai.models.generateContent({
    model: FLASH_MODEL,
    contents: prompt,
    config: { tools: [{ googleSearch: {} }] }
  });

  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sources = groundingChunks
    .filter((c: any) => c.web?.uri)
    .map((c: any) => ({ title: c.web.title || "Fuente", uri: c.web.uri }))
    .slice(0, 3);

  const data = extractJSON(response.text);
  if (!data.characters) data.characters = [];
  while (data.characters.length < 2) {
      data.characters.push({ name: `Hablante ${data.characters.length + 1}`, gender: 'male', voice: 'puck', bio: 'Local.' });
  }
  return { ...data, sources };
}

export async function generateDialogueAudio(scenario: HistoricalScenario): Promise<AudioBuffer> {
  // Always initialize a new instance before making an API call to ensure use of the most up-to-date API key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const speakerVoiceConfigs = scenario.characters.slice(0, 2).map((char, i) => ({
    speaker: `Speaker ${String.fromCharCode(65 + i)}`,
    voiceConfig: { prebuiltVoiceConfig: { voiceName: char.voice.toLowerCase() } }
  }));

  const charToSafeName = new Map();
  scenario.characters.forEach((c, i) => charToSafeName.set(c.name, `Speaker ${String.fromCharCode(65 + i)}`));

  const performTTS = async (useTranslation: boolean): Promise<AudioBuffer> => {
    let dialogueText = "";
    scenario.script.forEach(line => {
      const safeName = charToSafeName.get(line.speaker) || "Speaker A";
      const text = (useTranslation ? line.translation : line.text).replace(/\*[^*]+\*/g, '').trim();
      dialogueText += `${safeName}: ${text}\n`;
    });

    const response = await ai.models.generateContent({
      model: TTS_MODEL, 
      contents: [{ parts: [{ text: dialogueText }] }],
      config: {
        responseModalities: [Modality.AUDIO], 
        // Avoiding manual maxOutputTokens to prevent potential response blocking, as recommended.
        speechConfig: { multiSpeakerVoiceConfig: { speakerVoiceConfigs } }
      }
    });

    // Iterate through candidates and parts to find the audio part.
    const base64 = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;
    if (!base64) throw new Error("Audio fallido.");
    
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const buffer = await decodeAudioData(decodeBase64(base64), ctx, 24000, 1);
    await ctx.close();
    return buffer;
  };

  try { return await performTTS(false); } 
  catch { return await performTTS(true); }
}

export async function generateCharacterAvatar(description: string, context: string): Promise<string | null> {
  // Always initialize a new instance before making an API call to ensure use of the most up-to-date API key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: IMAGE_MODEL,
      contents: { parts: [{ text: `Detailed period portrait: ${description}. Historical Mexico context: ${context}. Cinematographic lighting.` }] }
    });
    // Iterate through candidates and parts to find the generated image part.
    const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
    return part ? `data:image/png;base64,${part.inlineData.data}` : null;
  } catch { return null; }
}
