
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState } from 'react';
import { SparklesIcon, SearchIcon, CalendarIcon, Loader2Icon } from 'lucide-react';

interface InputFormProps {
  onSubmit: (location: string, date: string, generateImages: boolean) => void;
  isLoading: boolean;
}

const PRESETS = [
  { label: "Tlatelolco", location: 'Mercado de Tlatelolco', date: '1519-08-01' },
  { label: "Independencia", location: 'Dolores Hidalgo', date: '1810-09-16' },
  { label: "5 de Mayo", location: 'Fuertes de Loreto, Puebla', date: '1862-05-05' },
];

export const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [location, setLocation] = useState('');
  const [date, setDate] = useState('');
  const [generateImages, setGenerateImages] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(location, date, generateImages);
  };

  return (
    <div className="w-full">
      <form onSubmit={handleSubmit} className="space-y-6 bg-white dark:bg-slate-800/60 p-6 md:p-10 rounded-[2.5rem] border border-stone-200 dark:border-slate-700 shadow-2xl backdrop-blur-sm">
        <div className="space-y-5">
          <div className="space-y-2">
            <label className="text-[10px] md:text-xs font-black text-red-700 dark:text-red-500 uppercase tracking-widest px-1">Lugar o Suceso Histórico</label>
            <div className="relative group flex items-center">
              <SearchIcon className="absolute left-4 text-stone-400 group-focus-within:text-red-600 transition-colors pointer-events-none" size={20} />
              <input
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Ej. Castillo de Chapultepec..."
                className="w-full bg-stone-50 dark:bg-slate-900 border-none rounded-2xl py-4 md:py-5 pl-12 md:pl-14 pr-4 text-base md:text-lg focus:ring-2 focus:ring-red-600 transition-all outline-none shadow-inner"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] md:text-xs font-black text-red-700 dark:text-red-500 uppercase tracking-widest px-1">Fecha aproximada</label>
            <div className="relative group flex items-center">
              <CalendarIcon className="absolute left-4 text-stone-400 group-focus-within:text-red-600 transition-colors pointer-events-none" size={20} />
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-stone-50 dark:bg-slate-900 border-none rounded-2xl py-4 md:py-5 pl-12 md:pl-14 pr-4 text-base md:text-lg focus:ring-2 focus:ring-red-600 transition-all outline-none cursor-pointer shadow-inner"
              />
            </div>
          </div>

          <label className="flex items-center gap-3 cursor-pointer group py-2 px-1">
            <input 
              type="checkbox"
              checked={generateImages}
              onChange={e => setGenerateImages(e.target.checked)}
              className="w-5 h-5 rounded border-stone-300 text-red-600 focus:ring-red-600 cursor-pointer"
            />
            <span className="text-xs md:text-sm font-medium text-stone-600 dark:text-slate-400 group-hover:text-red-700 transition-colors">Generar retratos de época con IA</span>
          </label>
        </div>

        <button
          type="submit"
          disabled={isLoading || !location}
          className="w-full py-4 md:py-5 rounded-2xl font-black text-lg md:text-xl bg-red-700 hover:bg-red-600 text-white shadow-xl shadow-red-900/20 flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50"
        >
          {isLoading ? <Loader2Icon className="animate-spin" size={24} /> : <SparklesIcon size={24} />}
          {isLoading ? 'SINTONIZANDO...' : 'ESCUCHAR EL PASADO'}
        </button>
        
        <div className="flex flex-wrap justify-center gap-2 pt-2">
            {PRESETS.map((p, i) => (
                <button
                    key={i}
                    type="button"
                    onClick={() => { setLocation(p.location); setDate(p.date); }}
                    className="text-[9px] md:text-[10px] px-3 py-1.5 bg-stone-100 dark:bg-slate-800 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-full border border-stone-200 dark:border-slate-700 transition-all text-stone-600 dark:text-stone-300"
                >
                    {p.label}
                </button>
            ))}
        </div>
      </form>
    </div>
  );
};
