
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useEffect, useRef, useState } from 'react';
import { PlayIcon, PauseIcon, RotateCcwIcon, UserIcon, EyeIcon, EyeOffIcon, RefreshCwIcon } from 'lucide-react';
import { HistoricalScenario, DialogueLine, Annotation, VoiceName } from '../types';

interface ScenarioDisplayProps {
  scenario: HistoricalScenario;
  audioBuffer: AudioBuffer | null;
  onRegenerateAudio?: (scenario: HistoricalScenario) => void;
  isRegenerating?: boolean;
}

const AVAILABLE_VOICES: VoiceName[] = [
  'achernar', 'achird', 'algenib', 'algieba', 'alnilam', 'aoede', 
  'autonoe', 'callirrhoe', 'charon', 'despina', 'enceladus', 'erinome', 
  'fenrir', 'gacrux', 'iapetus', 'kore', 'laomedeia', 'leda', 
  'orus', 'puck', 'pulcherrima', 'rasalgethi', 'sadachbia', 'sadaltager', 
  'schedar', 'sulafat', 'umbriel', 'vindemiatrix', 'zephyr', 'zubenelgenubi'
];

export const ScenarioDisplay: React.FC<ScenarioDisplayProps> = ({ scenario, audioBuffer, onRegenerateAudio, isRegenerating }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showAnnotations, setShowAnnotations] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const startTimeRef = useRef<number>(0);
  const pauseTimeRef = useRef<number>(0);

  const [localScenario, setLocalScenario] = useState(scenario);
  const voicesChanged = JSON.stringify(localScenario.characters.map(c => c.voice)) !== JSON.stringify(scenario.characters.map(c => c.voice));

  useEffect(() => {
    setLocalScenario(scenario);
  }, [scenario]);

  useEffect(() => {
    return () => {
      stopAudio();
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, [audioBuffer]);

  const initAudioContext = () => {
    if (!audioContextRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      audioContextRef.current = new AudioContextClass();
    }
  };

  const playAudio = () => {
    if (!audioBuffer) return;
    initAudioContext();
    const ctx = audioContextRef.current!;

    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);
    
    const offset = pauseTimeRef.current % audioBuffer.duration;
    
    source.start(0, offset);
    startTimeRef.current = ctx.currentTime - offset;
    sourceNodeRef.current = source;
    
    source.onended = () => {
        if (ctx.currentTime - startTimeRef.current >= audioBuffer.duration - 0.1) {
             setIsPlaying(false);
             pauseTimeRef.current = 0;
        }
    };

    setIsPlaying(true);
  };

  const stopAudio = () => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch (e) {}
      sourceNodeRef.current = null;
    }
    if (audioContextRef.current) {
        pauseTimeRef.current = audioContextRef.current.currentTime - startTimeRef.current;
    }
    setIsPlaying(false);
  };

  const resetAudio = () => {
      stopAudio();
      pauseTimeRef.current = 0;
  };

  const togglePlay = () => {
    if (isPlaying) {
      stopAudio();
    } else {
      playAudio();
    }
  };

  const handleVoiceChange = (charIdx: number, newVoice: VoiceName) => {
    const updatedChars = [...localScenario.characters];
    updatedChars[charIdx] = { ...updatedChars[charIdx], voice: newVoice };
    setLocalScenario({ ...localScenario, characters: updatedChars });
  };

  const renderAnnotatedText = (line: DialogueLine) => {
    if (!line.annotations || line.annotations.length === 0) {
      return line.text;
    }

    let result: React.ReactNode[] = [line.text];
    line.annotations.forEach((annotation: Annotation) => {
      const newResult: React.ReactNode[] = [];
      result.forEach(part => {
        if (typeof part === 'string') {
          const parts = part.split(new RegExp(`(${annotation.phrase})`, 'gi'));
          parts.forEach((subPart, i) => {
            if (subPart.toLowerCase() === annotation.phrase.toLowerCase()) {
              newResult.push(
                <span key={`${annotation.phrase}-${i}`} className="group relative cursor-help inline-block focus:outline-none" tabIndex={0}>
                  <span className="bg-red-600/[0.04] dark:bg-red-400/[0.06] border-b-2 border-red-200 dark:border-red-900 group-hover:border-red-500/50 px-1 -mx-0.5 rounded-sm transition-all duration-300 text-red-900 dark:text-red-100 font-bold">
                    {subPart}
                  </span>
                  <span className={`transition-all duration-300 absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-700 text-stone-800 dark:text-slate-200 text-xs rounded-lg whitespace-normal min-w-[180px] shadow-2xl z-50 pointer-events-none ${
                    showAnnotations ? 'visible opacity-100 translate-y-0' : 'invisible group-hover:visible group-focus:visible opacity-0 translate-y-1 group-hover:opacity-100 group-focus:opacity-100'
                  }`}>
                    <span className="font-bold text-red-600 dark:text-red-400 block mb-1 uppercase tracking-wider text-[10px]">{annotation.phrase}</span>
                    {annotation.explanation}
                    <span className="absolute left-1/2 bottom-0 transform -translate-x-1/2 translate-y-1/2 border-8 border-transparent border-t-white dark:border-t-slate-900"></span>
                  </span>
                </span>
              );
            } else { newResult.push(subPart); }
          });
        } else { newResult.push(part); }
      });
      result = newResult;
    });
    return result;
  };

  return (
    <div className="w-full space-y-6 md:space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      <div className="bg-white dark:bg-slate-800/80 border border-stone-200 dark:border-slate-700 rounded-3xl p-5 md:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-red-700"></div>
        <h2 className="font-serif-display text-lg md:text-2xl text-red-900 dark:text-red-50 mb-3 tracking-wide flex items-center gap-2">
            <span className="text-xl">📜</span> Escena Histórica
        </h2>
        <p className="text-stone-700 dark:text-slate-300 leading-relaxed text-sm md:text-lg font-medium italic">
          {scenario.context}
        </p>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-8 border-t border-stone-100 dark:border-slate-700 pt-8">
           {localScenario.characters.map((char, idx) => (
             <div key={idx} className="flex items-center gap-4 bg-stone-50/50 dark:bg-slate-900/30 p-4 rounded-2xl border border-stone-100 dark:border-slate-800">
                <div className="flex-shrink-0">
                    {char.avatarUrl ? (
                        <div className="w-16 h-16 md:w-24 md:h-24 rounded-full p-1 bg-red-700/10 ring-1 ring-red-700/20 shadow-lg overflow-hidden">
                             <img src={char.avatarUrl} alt={char.name} className="w-full h-full object-cover rounded-full" />
                        </div>
                    ) : (
                        <div className="w-16 h-16 md:w-24 md:h-24 rounded-full bg-stone-100 dark:bg-slate-700 flex items-center justify-center ring-1 ring-stone-200 dark:ring-slate-600">
                            <UserIcon size={30} className="text-stone-300 dark:text-slate-500" />
                        </div>
                    )}
                </div>
                <div>
                    <h4 className="font-serif-display text-sm md:text-lg text-red-800 dark:text-red-200 font-bold">{char.name}</h4>
                    <select 
                        value={char.voice} 
                        onChange={(e) => handleVoiceChange(idx, e.target.value as VoiceName)}
                        className="mt-1 bg-white dark:bg-slate-800 border border-stone-200 dark:border-slate-700 rounded-lg py-1 px-2 text-[10px] md:text-xs text-stone-600 dark:text-slate-300 outline-none capitalize"
                    >
                        {AVAILABLE_VOICES.map(v => <option key={v} value={v}>{v}</option>)}
                    </select>
                </div>
             </div>
           ))}
        </div>
      </div>

      <div className="bg-stone-50 dark:bg-slate-900/60 border-2 border-dashed border-stone-200 dark:border-slate-700 rounded-3xl p-6 md:p-10 flex flex-col items-center justify-center space-y-6 shadow-inner">
        <div className="flex items-center gap-6">
            <button onClick={resetAudio} className="p-3 rounded-full text-stone-400 hover:text-red-700 transition-all active:scale-90"><RotateCcwIcon size={24} /></button>
            <button
                onClick={togglePlay}
                disabled={!audioBuffer || isRegenerating}
                className="w-20 h-20 md:w-28 md:h-28 rounded-full bg-red-700 hover:bg-red-600 text-white shadow-2xl shadow-red-900/40 flex items-center justify-center transition-all active:scale-95 disabled:opacity-50"
            >
                {isPlaying ? <PauseIcon size={40} fill="currentColor" /> : <PlayIcon size={40} fill="currentColor" className="ml-1" />}
            </button>
            {voicesChanged ? (
                <button 
                    onClick={() => onRegenerateAudio?.(localScenario)}
                    className="p-3 rounded-full bg-stone-800 text-white hover:bg-red-700 shadow-lg transition-all animate-pulse"
                ><RefreshCwIcon size={24} /></button>
            ) : <div className="w-12"></div>}
        </div>
        <p className="text-[10px] md:text-xs font-black text-red-700 dark:text-red-500 tracking-[0.2em] uppercase">
            {isPlaying ? 'Escuchando el pasado...' : 'Listo para reproducir'}
        </p>
      </div>

      <div className="space-y-8 pb-10">
        <div className="flex justify-center">
            <button
                onClick={() => setShowAnnotations(prev => !prev)}
                className="flex items-center gap-2 text-[10px] md:text-xs font-bold text-red-800 dark:text-red-400 bg-red-50 dark:bg-red-950/30 px-5 py-2 rounded-full border border-red-100 dark:border-red-900/50 transition-all"
            >
                {showAnnotations ? <EyeOffIcon size={14} /> : <EyeIcon size={14} />}
                {showAnnotations ? 'OCULTAR GLOSARIO' : 'MOSTRAR GLOSARIO'}
            </button>
        </div>

        <div className="space-y-10 px-2">
          {scenario.script.map((line, idx) => (
            <div key={idx} className={`flex flex-col ${idx % 2 === 0 ? 'items-start' : 'items-end'}`}>
              <div className={`flex gap-3 md:gap-5 max-w-[95%] md:max-w-[85%] ${idx % 2 === 0 ? 'flex-row' : 'flex-row-reverse text-right'}`}>
                 <div className="flex-shrink-0 mt-1">
                    {(() => {
                        const char = scenario.characters.find(c => c.name === line.speaker) || scenario.characters[idx % 2];
                        return char?.avatarUrl ? (
                            <img src={char.avatarUrl} alt={char.name} className="w-10 h-10 md:w-14 md:h-14 rounded-full object-cover border-2 border-white dark:border-slate-700 shadow-md" />
                        ) : (
                             <div className="w-10 h-10 md:w-14 md:h-14 rounded-full bg-stone-200 flex items-center justify-center text-xs font-bold">{char?.name?.[0]}</div>
                        );
                    })()}
                 </div>
                 <div className="space-y-1">
                    <span className="text-[9px] md:text-[11px] text-red-700 dark:text-red-500 font-black tracking-widest uppercase">{line.speaker}</span>
                    <p className="font-serif-display text-base md:text-2xl text-stone-800 dark:text-slate-100 leading-tight">"{renderAnnotatedText(line)}"</p>
                    {line.translation && <p className="text-xs md:text-sm text-stone-500 dark:text-slate-400 italic mt-1">{line.translation}</p>}
                 </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
